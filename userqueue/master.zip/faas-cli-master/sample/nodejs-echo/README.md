This sample Node.js function will return the Node.js version and the input to the function.
