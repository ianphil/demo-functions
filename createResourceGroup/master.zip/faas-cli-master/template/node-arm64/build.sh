#!/bin/sh

echo "Building functions/base:node-6.9.1-alpine"
docker build -t functions/base:node-6.9.1-alpine .

